package com.example.quize

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var quizebtn : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        quizebtn = findViewById<Button>(R.id.btnPlayQuiz)
        quizebtn.setOnClickListener {
            val intent = Intent(this@MainActivity, Quize_Question::class.java)
            startActivity(intent)
        }
    }
}