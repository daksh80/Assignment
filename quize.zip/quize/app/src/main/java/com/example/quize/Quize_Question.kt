package com.example.quize

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.IOException
import java.nio.charset.Charset

class Quize_Question : AppCompatActivity() {
    lateinit var id :TextView
    lateinit var question : TextView
    lateinit var Option1 : TextView
    lateinit var Option2 : TextView
    lateinit var Option3 : TextView
    lateinit var Option4 : TextView
    lateinit var scoreid: TextView
    var questionId: JSONObject?= null
    var EditId: String?= null
    var Editquestion: String?=null
    var option: JSONObject?= null
    var EditOption1: String?=null
    var EditOption2: String?=null
    var EditOption3: String?=null
    var EditOption4: String?=null
    var EditCorrectIndex: String?=null
    var count=0
    var k =0

    val questionList: ArrayList<QuestionModelClass> = ArrayList()
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quize_question)
        id = findViewById<TextView>(R.id.questionNo)
        question = findViewById<TextView>(R.id.question)
        Option1 = findViewById<TextView>(R.id.option1)
        Option2 = findViewById<TextView>(R.id.option2)
        Option3 = findViewById<TextView>(R.id.option3)
        Option4 = findViewById<TextView>(R.id.option4)
        scoreid = findViewById<TextView>(R.id.score)

        val obj = JSONObject(getJsonFromAssets())
        val questionArray = obj.getJSONArray("questions")
        questionId = questionArray.getJSONObject(k)
        EditText(id , question, Option1,Option2,Option3,Option4)


        Option1.setOnClickListener{
            k++;
            if(EditOption1?.equals(EditCorrectIndex) == true){
                oncclickholder()
            }

            questionId = questionArray.getJSONObject(k)
            EditText(id , question, Option1,Option2,Option3,Option4)
        }
        Option2.setOnClickListener{
            k++;
            if(EditOption2?.equals(EditCorrectIndex) == true){
                oncclickholder()
            }
            questionId = questionArray.getJSONObject(k)
            EditText(id , question, Option1,Option2,Option3,Option4)
        }
        Option3.setOnClickListener{
            k++;
            if(EditOption3?.equals(EditCorrectIndex) == true){
                oncclickholder()
            }
            questionId = questionArray.getJSONObject(k)
            EditText(id , question, Option1,Option2,Option3,Option4)
        }

        Option4.setOnClickListener{
            k++;
            if(EditOption4?.equals(EditCorrectIndex) == true){
                oncclickholder()
            }
            questionId = questionArray.getJSONObject(k)
            EditText(id , question, Option1,Option2,Option3,Option4)
        }



    }
    private fun getJsonFromAssets(): String{
        var json: String? = null
        val charset: Charset = Charsets.UTF_8
        try {
            val myQuestionJsonFile = this@Quize_Question.assets.open("question.json")
            val size = myQuestionJsonFile.available()
            val buffer = ByteArray(size)
            myQuestionJsonFile.read(buffer)
            myQuestionJsonFile.close()
            json = String(buffer,charset)
        }catch (ex: IOException){
            ex.printStackTrace()
            return ""
        }
        return json
    }
    fun EditText(
        id: TextView, question: TextView, Option1: TextView,
        Option2: TextView,
        Option3: TextView,
        Option4: TextView,

    ){
        EditId = questionId?.getString("id")
        Editquestion = questionId?.getString("question")
         option = questionId?.getJSONObject("answers")
         EditOption1 = option?.getString("Option1")
         EditOption2 = option?.getString("Option2")
         EditOption3 = option?.getString("Option3")
         EditOption4 = option?.getString("Option4")
         EditCorrectIndex = questionId?.getString("correctIndex")


        id.text = EditId.toString()
        question.text = Editquestion.toString()
        Option1.text = EditOption1.toString()
        Option2.text = EditOption2.toString()
        Option3.text = EditOption3.toString()
        Option4.text = EditOption4.toString()
        val questionDetails = Editquestion?.let {
            EditOption1?.let { it1 ->
                EditOption2?.let { it2 ->
                    EditOption3?.let { it3 ->
                        EditOption4?.let { it4 ->
                            EditCorrectIndex?.let { it5 ->
                                EditId?.let { it6 ->
                                    QuestionModelClass(
                                        it6.toInt(),
                                        it, it1, it2, it3, it4, it5
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        if (questionDetails != null) {
            questionList.add(questionDetails)
        }

    }
    fun oncclickholder(){
        count++
        Toast.makeText(this@Quize_Question,"Correct ohh yeah ${count}",Toast.LENGTH_LONG).show()
        scoreid.setText("${count}").toString()
    }
    
}


