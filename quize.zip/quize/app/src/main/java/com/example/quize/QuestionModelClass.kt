package com.example.quize

class QuestionModelClass (
    val id: Int,
    val question: String,
    val Option1: String,
    val Option2 : String,
    val Option3 : String,
    val Option4 : String,
    val correctIndex: String
        )